import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Load the dataset
data = pd.read_csv('Cars.csv')

# Select features (X) and target variable (y)
X = data[['Location', 'Year', 'Kilometers_Driven', 'Fuel_Type', 'Transmission',
          'Owner_Type', 'Mileage', 'Engine', 'Power', 'Seats',
          'No. of Doors', 'New_Price']]
y = data['Price']

# Handle missing values (if any)
X = X.copy()  # Create a copy of the DataFrame
X.fillna(value=0, inplace=True)

# Encode categorical variables
X_encoded = pd.get_dummies(X)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

# Create a Random Forest regression model
model = RandomForestRegressor(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error (MSE):", mse)
print("Mean Absolute Error (MAE):", mae)
print("R-squared (R2):", r2)

# Predict the price of a new car
new_car = pd.DataFrame({
    'Location': ['Mumbai'],
    'Year': [2020],
    'Kilometers_Driven': [50000],
    'Fuel_Type': ['Petrol'],
    'Transmission': ['Automatic'],
    'Owner_Type': ['First'],
    'Mileage': ['15 kmpl'],
    'Engine': ['1497 CC'],
    'Power': ['120 bhp'],
    'Seats': [5],
    'No. of Doors': [4],
    'New_Price': ['8.9 Lakh']
})

new_car_encoded = pd.get_dummies(new_car)
new_car_encoded = new_car_encoded.reindex(columns=X_encoded.columns, fill_value=0)

predicted_price = model.predict(new_car_encoded)
print("Predicted Price:", predicted_price)
